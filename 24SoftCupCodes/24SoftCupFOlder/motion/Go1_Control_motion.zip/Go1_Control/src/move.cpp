/**********************************************************************
 Copyright (c) 2020-2023, Unitree Robotics.Co.Ltd. All rights reserved.
***********************************************************************/

#include "move.h"

void Custom::UDPRecv()
{
    udp.Recv();
}

void Custom::UDPSend()
{
    udp.Send();
}

void Custom::cmdReset() {
    cmd.mode = 0;
    cmd.gaitType = 0;
    cmd.speedLevel = 0;
    cmd.footRaiseHeight = 0;
    cmd.bodyHeight = 0;
    cmd.euler[0] = 0;
    cmd.euler[1] = 0;
    cmd.euler[2] = 0;
    cmd.velocity[0] = 0.0f;
    cmd.velocity[1] = 0.0f;
    cmd.yawSpeed = 0.0f;
    cmd.reserve = 0;
}

void Custom::RightCorrect() {
    cmd.mode = 2;      // 0:idle, default stand      1:forced stand     2:walk continuously
    cmd.gaitType = 1;
    cmd.yawSpeed = -0.2f;
    cmd.velocity[0] = 0.0f;
    cmd.yawSpeed = -0.5f;
    std::cout << "now Correct" << endl;
}

void Custom::RobotControl()
{
    udp.GetRecv(state);
    // std::cout << "state.mode: " << static_cast<int>(state.mode) << std::endl;
    // std::cout << "state.bodyHeight: " << state.bodyHeight << std::endl;

    // std::cout << "cmd.mode: " << static_cast<int>(cmd.mode) << std::endl;
    // std::cout << "cmd.bodyHeight: " << cmd.bodyHeight << std::endl;

    // std::cout << cmd.velocity[0] << " " << cmd.velocity[1] << " " << cmd.yawSpeed << std::endl;

    udp.SetSend(cmd);
}

void Custom::rise() {
    cmdReset(); cmd.mode = 1;
    cmd.euler[1] = -0.60;     sleep(3);
    cmdReset();
}
void Custom::lower() {
    cmdReset(); cmd.mode = 1;
    cmd.euler[1] = 0.60;     sleep(3);
    cmdReset();
}
void Custom::warning() {
    cmdReset(); 
    FaceLightClient client;
    /* Same Color Test */
    client.setAllLed(client.red);
    client.sendCmd();
    usleep(1200000);
    client.setAllLed(client.blue);
    client.sendCmd();
    usleep(1200000);
    client.setAllLed(client.red);
    client.sendCmd();
    usleep(1200000);
    client.setAllLed(client.blue);
    client.sendCmd();
    usleep(1200000);
    client.setAllLed(client.black);
    client.sendCmd();
}

void Custom::putLeft()
{
    cmdReset(); cmd.mode = 1;
    cmd.euler[1] = -0.75;     sleep(1);
    cmd.euler[1] = 0.0;     sleep(1);
    cmd.bodyHeight = -0.2;  sleep(1);
    cmd.euler[0] = -0.75;   sleep(1);
    cmd.euler[0] = 0;       sleep(1);
    cmd.bodyHeight = 0;     sleep(1);
}
void Custom::putRight()
{
    cmdReset(); cmd.mode = 1;
    cmd.euler[1] = +0.75;     sleep(1);
    cmd.euler[1] = 0.0;     sleep(1);
    cmd.bodyHeight = -0.2;  sleep(1);
    cmd.euler[0] = +0.75;   sleep(1);
    cmd.euler[0] = 0;       sleep(1);
    cmd.bodyHeight = 0;     sleep(1);
}
void Custom::setVelocity(float vx, float vy, float vr)
{
    cmdReset(); cmd.mode = 2;
    cmd.gaitType = 1;
    cmd.velocity[0] = vx;
    cmd.velocity[1] = vy;
    cmd.yawSpeed = vr;
}

void Custom::Start()
{
    std::cout << "Communication level is set to HIGH-level." << std::endl
              << "WARNING: Make sure the robot is standing on the ground." << std::endl
              << "Press Enter to continue..." << std::endl;

    Custom custom(HIGHLEVEL);
    LoopFunc loop_control("control_loop", dt,    boost::bind(&Custom::RobotControl, this));
    LoopFunc loop_udpSend("udp_send",     dt, 3, boost::bind(&Custom::UDPSend,      this));
    LoopFunc loop_udpRecv("udp_recv",     dt, 3, boost::bind(&Custom::UDPRecv,      this));

    loop_udpSend.start();
    loop_udpRecv.start();
    loop_control.start();

    while (1)
    {
        sleep(10);
    };
}