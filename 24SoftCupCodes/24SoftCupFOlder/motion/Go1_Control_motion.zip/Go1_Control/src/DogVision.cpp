#include "DogVision.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>

// 无参构造, 只是打开摄像头
DogVision::DogVision() : cam("../config/stereo_camera_config.yaml") {

}

// 有参构造, 构造函数会读取配置文件，并根据文件内容设置参数值, 并传入控制运动的指针
DogVision::DogVision(const std::string& configFile, Custom* myPlan) : cam("/home/unitree/Documents/24SoftCupCodes/24SoftCupFOlder/motion/Go1_Control/config/stereo_camera_config.yaml") {
    custom = myPlan;
    std::ifstream config_file(configFile);
    std::string line;
    // read the config file
    while (std::getline(config_file, line)) {
        std::istringstream iss(line);
        std::string name;
        int value;
        char equal_sign;
        if (!(iss >> name >> equal_sign >> value) || equal_sign != '=') {
            throw std::runtime_error("Error parsing config file: " + line);
        }
        if (name == "cannyThreshold") {
            cannyThreshold = value;
        } else if (name == "cannyThresholdMax") {
            cannyThresholdMax = value;
        } else if (name == "houghThreshold") {
            houghThreshold = value;
        } else if (name == "houghMinLineLength") {
            houghMinLineLength = value;
        } else if (name == "houghMaxLineGap") {
            houghMaxLineGap = value;
        } else if (name == "yellowHLower") {
            yellowHLower = value;
        } else if (name == "yellowSLower") {
            yellowSLower = value;
        } else if (name == "yellowVLower") {
            yellowVLower = value;
        } else if (name == "yellowHUpper") {
            yellowHUpper = value;
        } else if (name == "yellowSUpper") {
            yellowSUpper = value;
        } else if (name == "yellowVUpper") {
            yellowVUpper = value;
        } else if (name == "lowerAngel") {
            lowerAngel = value;
        } else if (name == "upperAngel") {
            upperAngel = value;
        } else if (name == "dropNode1") {

        } else if (name == "dropNode2") {

        } else if (name == "dropNode3") {

        } else if (name == "dropNode4") {

        } else {
            throw std::runtime_error("Unknown parameter in config file: " + name);
        }
    }
}


// 这个函数用于处理图像，你需要根据你的具体需求来实现这个函数。
void DogVision::processImage(cv::Mat& src) {
    // 获取图像的尺寸
    int rows = src.rows;
    int cols = src.cols;

    // 计算裁剪区域
    int top = rows / 5;
    int bottom = rows * 4 / 5;
    int left = cols / 5;
    int right = cols * 4 / 5;

    // 创建ROI
    cv::Rect roi(left, top, right - left, bottom - top);

    // 裁剪图像
    cv::Mat frame = src(roi);

    // 寻找中点
    cv::Point midPointLine, midPointimage(frame.cols / 2, frame.rows / 2);
    int degreeK;
    lineProcessor.lineFit(frame, midPointLine, degreeK);
    std::cout << "midPointLine: " << midPointLine << " degreeK: " << degreeK << std::endl;
    cv::circle(frame, midPointimage, 5, cv::Scalar(255, 0, 255), -1);
    if (midPointLine.x != 0 && midPointLine.y != 0) cv::circle(frame, midPointLine, 5, cv::Scalar(0, 0, 255), -1);  // 绘制一个红色的小圆点
    imshow("img", frame);
    custom->cmd.mode = 2;
    custom->cmd.gaitType = 1;
    custom->cmd.velocity[0] = 0.12f;
    custom->cmd.velocity[1] = -0.0125f;//DO NOT ADJUST DEFAULT VALUE
// use motiontime to control:
    if (degreeK >= 0 && degreeK <= 20 || degreeK >=140 && degreeK <= 180) {
        custom->RightCorrect();
        sleep(6);
        custom->cmd.yawSpeed = 0.012f;

    }else {
        int result = midPointimage.x - midPointLine.x;
        //cout << "result: " << result << endl;
        if (midPointimage.x - midPointLine.x > 20) {
            custom->cmd.velocity[1] = -0.10f;
            // cout << "now go Left!" << endl;
        } else if (midPointimage.x - midPointLine.x < -20) {
            custom->cmd.velocity[1] = +0.10f;
            //cout << "now go Right!" << endl;
        }
        if (degreeK<85&&degreeK>20) custom->cmd.yawSpeed = +0.10f;
        else if(degreeK>95&&degreeK<140) custom->cmd.yawSpeed = -0.10f;
        else custom->cmd.yawSpeed = 0.012f;

    }
}

void DogVision::detectYellow(cv::Mat& image)
{

}


void DogVision::Start() {
    int deviceNode = 0; ///< default 0 -> /dev/video0
    cv::Size frameSize(1856, 800); ///< default frame size 1856x800
    int fps = 30; ///< default camera fps: 30
    if (!cam.isOpened())   ///< get camera open state
        exit(EXIT_FAILURE);

    cam.setRawFrameSize(frameSize); ///< set camera frame size
    cam.setRawFrameRate(fps);       ///< set camera camera fps
    cam.setRectFrameSize(cv::Size(frameSize.width >> 2, frameSize.height >> 1)); ///< set camera rectify frame size
    cam.startCapture(); ///< disable image h264 encoding and share memory sharing

    usleep(500000);
    while (cam.isOpened()) {
        cv::Mat left, right, film, film_clone;
        if (!cam.getRectStereoFrame(left, right, film)) { ///< get rectify left,right frame
            usleep(1000);
            continue;
        }
        film_clone = film.clone();
        processImage(film);
        //detectYellow(film_clone);
        char key = cv::waitKey(10);
        if (key == 27) // press ESC key
            break;
    }
    cam.stopCapture();
}


