sudo route add default gw 192.168.123.161 dev wlan0 metric 0
sudo ntpdate ntp.ubuntu.com
